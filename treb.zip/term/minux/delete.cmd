cd..
del term.cmd