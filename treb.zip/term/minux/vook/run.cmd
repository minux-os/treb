echo Vook is launched!
@echo off
chcp 65001 >nul
echo Welcome to vook!
timeout /t 5
cls
title Minux

echo Welcome To Vook!

:minux
set /p command="vook@minux:~$ "

if "%command%"=="" goto vget